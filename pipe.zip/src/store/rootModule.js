const rootModule = {
    state: {},
    mutations: {},
    actions: {},
    modules: {}
};
export default rootModule;