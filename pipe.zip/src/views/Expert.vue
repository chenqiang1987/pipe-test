<template>
  <div id="expert">
    这是专家协助页面66666666666666666666
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
