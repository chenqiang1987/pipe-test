export default {
    allRoles: '/role/authc/allRoles', //查询系统所有角色
    addOne:'/role/authc/addOne', //添加单个角色
    deleteOne:'/role/authc/deleteOne', //删除单个角色
    modifyOne:'/role/authc/modifyOne', //修改单个角色
}