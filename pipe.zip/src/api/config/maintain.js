export default {
  faultType: '/maintain/authc/faultType', //故障类型
  selectPage: '/maintain/authc/selectPage', //分页获取工单列表
  startRepair: '/maintain/authc/startRepair', //开始维修
  resolveRepair: '/maintain/authc/resolveRepair', //解决维修
  unResolveRepair: '/maintain/authc/unResolveRepair', //未解决维修
  createWorkOrder: '/maintain/authc/createWorkOrder' //创建工单
}
