export default {
    allPermits: '/permit/authc/allPermits', // 系统所有的菜单资源-树形结构
    getPermitByRoleId: '/permit/authc/getPermitByRoleId', // 获取角色的菜单资源-树形结构
    setPermitForRoleId: '/permit/authc/setPermitForRoleId' // 给角色设置菜单
}