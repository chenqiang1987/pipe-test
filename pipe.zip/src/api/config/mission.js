export default {
    batchAutoMession: '/mession/authc/addAutoMession', //批量新建删除自动任务
    getAutoMessions: '/mession/authc/getAutoMessions', //获取机器人自动任务列表
}